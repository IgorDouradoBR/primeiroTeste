import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.LinkedList;
import java.util.Iterator;

public class  MetodoSemNome{
    Set<Integer> listaMatricula= new HashSet<Integer>();

    
    public List<Integer> matriculaUnica(List<Integer> listaOriginal){
        ListIterator<Integer> iter = listaOriginal.listIterator();
        while(iter.hasNext()){
            listaMatricula.add(iter.next());
        }
        List<Integer> listaNova= new LinkedList<Integer>();
        for(Integer adiciona: listaMatricula){
            listaNova.add(adiciona);
        }
        return listaNova;
    }

}